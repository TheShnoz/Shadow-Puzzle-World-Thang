		SHADOW WORLD

README

	Shadow World is an isometric(2.5D) puzzle game where you explore the dark and empty world
	trying to find another creature like you. As you play you find new forms/genomes to transform 
	into to help you traverse the world and complete puzzles. 

	The ending of Shadow World depends on how many puzzles you complete with a certain form/genome
	to promote replayability.

	This game is supposed to provoke a loneliness and a drive to find a connection with another
	shadow creature. It is a synthesis of art and technology to make something truly sublime.

CONTACT

	If you have any problems, questions, ideas, or suggestions, please contact us by 
	emailing: stouta@g.cofc.edu

	Contributors: Aidan Stout, Andrew Turner, Carter Quattlebaum, Reed Reed

GIT

	To download the latest version of Shadow World:
	https://github.com/TheShnoz/Shadow-Puzzle-World-Thang

LATEST RELEASE

	To play the most recent release of Shadow World, access the "release!!" file in the repository

NOTICE
	
	This is a prototype project created in the Computing in the Arts Practicum class at the College
	of Charleston.